// Serlino Brain Desktop's page. It reads only through the app's bridge (`ask`) and can ask the app
// for the few things it cannot do itself (`act`: Claude Code, Terminal, Finder, a web link).
// Text always goes in as text (the `h` helper); the one HTML it inserts is markdown, sanitised.
import { marked } from './vendor/marked.esm.js';
import DOMPurify from './vendor/purify.es.mjs';

const VERSION = new URLSearchParams(location.search).get('v') || 'dev';
const handlers = window.webkit?.messageHandlers;
const BRAND = 'SerlinoLab';
const FOLDER_TITLE = { brand: `${BRAND}'s brain`, team: 'Team files', personal: 'Personal files' };
const CHIP = { brand: BRAND, team: 'Team', personal: 'Personal' };
const BADGE = { added: 'Added', edited: 'Edited', deleted: 'Deleted', moved: 'Moved' };
const PAGE_SIZE = 30;
const TREE_ROWS = 12;   // a card shows this many files before "+ N more"

async function ask(req) {
  if (!handlers?.brain) throw new Error('Open this page from the Serlino Brain app.');
  const out = JSON.parse(await handlers.brain.postMessage(JSON.stringify(req)));
  if (out.error) throw new Error(out.error);
  return out;
}
const act = (req) => handlers?.act?.postMessage(JSON.stringify(req));

// ---------- tiny DOM helpers ----------

function h(tag, attrs = {}, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (v == null || v === false) continue;
    if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
    else if (k === 'class') el.className = v;
    else el.setAttribute(k, v === true ? '' : v);
  }
  for (const kid of kids.flat()) if (kid != null && kid !== false) el.append(kid instanceof Node ? kid : String(kid));
  return el;
}

const ICONS = {
  map: '<circle cx="6" cy="7" r="2.2"/><circle cx="17.5" cy="5.5" r="2.2"/><circle cx="16" cy="17" r="2.2"/><circle cx="6.5" cy="17.5" r="2.2"/><path d="M8 8.2 14.3 15.6M8.1 6.6l7.2-1M16.8 7.7 16.2 14.8M8.7 17.4h5.1"/>',
  activity: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 9.5V20h13V9.5"/><path d="M10 20v-5h4v5"/>',
  team: '<path d="M4 20V6l7-3v17"/><path d="M11 9h9v11"/><path d="M2 20h20"/><path d="M7 8v.01M7 12v.01M7 16v.01M15 13v.01M15 17v.01"/>',
  brand: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  personal: '<circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  file: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  reload: '<path d="M20 11a8 8 0 1 0-2.3 5.7"/><path d="M20 4v7h-7"/>',
  finder: '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 10h18"/>',
  left: '<path d="m15 18-6-6 6-6"/>', right: '<path d="m9 18 6-6-6-6"/>', down: '<path d="m6 9 6 6 6-6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>', x: '<path d="M6 6l12 12M18 6 6 18"/>',
  home: '<path d="M3 11.5 12 4l9 7.5"/><path d="M5.5 9.5V20h13V9.5"/>',
  sidebar: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M9 4v16"/>',
  column: '<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M15 4v16"/>',
  terminal: '<path d="m5 7 5 5-5 5"/><path d="M12 18h7"/>',
  claude: '<path d="M12 3v18M3 12h18M5.6 5.6l12.8 12.8M18.4 5.6 5.6 18.4"/>',
};
function icon(name, cls = '') {
  const t = document.createElement('template');
  t.innerHTML = `<svg class="i ${cls}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[name]}</svg>`;   // constant markup only
  return t.content.firstChild;
}

// ---------- time ----------

const rel = new Intl.RelativeTimeFormat('en', { numeric: 'auto' });
function ago(iso) {
  const s = (new Date(iso) - Date.now()) / 1000;
  const steps = [[60, 'second'], [60, 'minute'], [24, 'hour'], [7, 'day'], [4.35, 'week'], [12, 'month'], [Infinity, 'year']];
  let v = s;
  for (const [n, unit] of steps) {
    if (Math.abs(v) < n) return unit === 'second' ? 'just now' : rel.format(Math.round(v), unit);
    v /= n;
  }
}
const dayFmt = new Intl.DateTimeFormat(undefined, { weekday: 'short', day: 'numeric', month: 'short' });
const dayKey = (iso) => new Date(iso).toDateString();
const shortWhen = (iso) => {
  const d = new Date(iso);
  return Date.now() - d < 7 * 864e5 ? ago(iso) : d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' });
};

// ---------- state: tabs, each with its own back/forward ----------

let state = { folders: [], sync: null, person: null };
const tabs = [];
let active = 0;
let uid = 0;
const prefs = (() => { try { return JSON.parse(localStorage.getItem('prefs') || '{}'); } catch { return {}; } })();
const savePrefs = () => { try { localStorage.setItem('prefs', JSON.stringify(prefs)); } catch {} };

const tab = () => tabs[active];
const route = () => tab().stack[tab().at];

function newTab(r) { tabs.push({ id: ++uid, stack: [r], at: 0 }); active = tabs.length - 1; render(); }
function go(r) {
  const t = tab();
  t.stack = t.stack.slice(0, t.at + 1);
  t.stack.push(r);
  t.at++;
  render();
}
function step(d) { const t = tab(); t.at = Math.max(0, Math.min(t.stack.length - 1, t.at + d)); render(); }
function closeTab(i) {
  tabs.splice(i, 1);
  if (!tabs.length) tabs.push({ id: ++uid, stack: [{ page: 'activity' }], at: 0 });
  active = Math.min(active, tabs.length - 1);
  render();
}

function title(r) {
  if (r.page === 'activity') return 'Home';
  if (r.page === 'map') return 'Brain map';
  if (!r.path) return FOLDER_TITLE[r.folder];
  return r.path.split('/').pop();
}

// ---------- shell ----------

function renderSidebar() {
  const r = route();
  const item = (key, label, onclick, isActive) =>
    h('button', { class: 'navitem' + (isActive ? ' active' : ''), onclick }, icon(key), h('span', {}, label));
  const sync = state.sync;
  const brains = state.folders.filter((f) => f.isRepo).length;
  const syncText = !sync || sync.level === 'off' ? 'Not syncing on this Mac'
    : sync.level === 'stale' ? `Last synced ${ago(new Date(Date.now() - sync.minutesAgo * 60000))}`
    : `Synced · ${brains} brain${brains === 1 ? '' : 's'}`;
  const person = state.person || 'You';
  document.getElementById('sidebar').replaceChildren(
    h('div', { class: 'brandhead' },
      h('img', { class: 'mark', src: 'brand/serlinolab-s.png', alt: '' }),
      h('img', { class: 'wordmark', src: 'brand/wordmark.png', alt: BRAND }),
      h('div', { class: 'ver' }, 'Brain', h('b', {}, VERSION))),
    h('button', { class: 'navitem', onclick: () => openSearch() }, icon('search'), h('span', {}, 'Search'),
      h('span', { class: 'kbd' }, h('kbd', {}, '⌘'), h('kbd', {}, 'K'))),
    h('div', { class: 'side-label' }, 'Workspace'),
    item('activity', 'Activity', () => go({ page: 'activity' }), r.page === 'activity'),
    item('map', 'Brain map', () => go({ page: 'map' }), r.page === 'map'),
    item('team', 'Team files', () => go({ page: 'folder', folder: 'team', path: '' }), r.folder === 'team'),
    item('brand', 'Brand knowledge', () => go({ page: 'folder', folder: 'brand', path: '' }), r.folder === 'brand'),
    item('personal', 'Personal files', () => go({ page: 'folder', folder: 'personal', path: '' }), r.folder === 'personal'),
    h('div', { class: 'side-spacer' }),
    h('div', { class: 'side-rule' }),
    h('div', { class: 'brandblock' }, h('img', { class: 'avatar', src: 'brand/serlinolab-s.png', alt: '' }),
      h('div', {}, h('small', {}, 'Brand'), h('span', {}, BRAND))),
    h('div', { class: 'syncline', title: sync?.minutesAgo != null ? `Last sync cycle ${sync.minutesAgo} min ago` : '' },
      h('span', { class: 'dot ' + (sync?.level || 'off') }), h('span', {}, syncText),
      h('button', { title: 'Open Terminal in the brain', onclick: () => act({ action: 'terminal', folder: 'brand', path: '' }) }, icon('terminal', 'sm'))),
    h('div', { class: 'side-rule' }),
    h('div', { class: 'account' }, h('div', { class: 'avatar' }, person[0].toUpperCase()), h('span', {}, person)),
  );
}

function renderTabs() {
  document.getElementById('tabbar').replaceChildren(
    h('button', { class: 'tb-btn', title: 'Show or hide the sidebar', onclick: () => document.getElementById('app').classList.toggle('no-sidebar') }, icon('sidebar')),
    h('button', { class: 'tb-btn', title: 'Home', onclick: () => go({ page: 'activity' }) }, icon('home')),
    ...tabs.map((t, i) => h('div', { class: 'tab' + (i === active ? ' active' : ''), onclick: () => { active = i; render(); } },
      h('span', { class: 't' }, title(t.stack[t.at])),
      h('button', { class: 'x', title: 'Close tab', onclick: (e) => { e.stopPropagation(); closeTab(i); } }, icon('x', 'sm')))),
    h('div', { class: 'grow' }),
    h('button', { class: 'tb-btn', title: 'New tab', onclick: () => openSearch({ inNewTab: true }) }, icon('plus')),
  );
}

let renderSeq = 0;
async function render() {
  renderSidebar();
  renderTabs();
  const seq = ++renderSeq;
  const r = route();
  const page = document.getElementById('page');
  const view = r.page === 'activity' ? activityView() : r.page === 'map' ? mapView() : r.page === 'file' ? fileView(r) : folderView(r);
  page.replaceChildren(view.el);
  page.scrollTop = 0;
  try { await view.load(() => seq === renderSeq); } catch (e) { if (seq === renderSeq) view.fail?.(e); }
}

// ---------- shared pieces ----------

function toolbar(r, last) {
  const t = tab();
  const crumbs = h('div', { class: 'crumbs' });
  const parts = r.path ? r.path.split('/') : [];
  const root = h(parts.length ? 'button' : 'span', { class: parts.length ? '' : 'here', onclick: () => go({ page: 'folder', folder: r.folder, path: '' }) }, FOLDER_TITLE[r.folder]);
  crumbs.append(root);
  parts.forEach((p, i) => {
    const sub = parts.slice(0, i + 1).join('/');
    crumbs.append(h('span', { class: 'sep' }, '/'),
      i === parts.length - 1 ? h('span', { class: 'here' }, p) : h('button', { onclick: () => go({ page: 'folder', folder: r.folder, path: sub }) }, p));
  });
  const lastmod = h('span', { class: 'lastmod' });
  const setLast = (c) => { lastmod.textContent = c ? `Last modified ${ago(c.date)} by ${c.author}` : ''; };
  setLast(last);
  const bar = h('div', { class: 'toolbar' },
    h('button', { class: 'nav', disabled: t.at === 0, onclick: () => step(-1), title: 'Back' }, icon('left')),
    h('button', { class: 'nav', disabled: t.at === t.stack.length - 1, onclick: () => step(1), title: 'Forward' }, icon('right')),
    crumbs, h('div', { class: 'grow' }), lastmod,
    workButton(r.folder, r.path, r.page === 'file' ? 'Work on this file' : 'Work on this'));
  return { bar, setLast };
}

function workButton(folder, path, label, small = false) {
  const wrap = h('div', { class: 'work' + (small ? ' small' : '') });
  let menu = null;
  const close = () => { menu?.remove(); menu = null; document.removeEventListener('click', close); };
  wrap.append(
    h('button', { onclick: (e) => { e.stopPropagation(); act({ action: 'claude', folder, path }); } }, h('span', { class: 'star' }, '✳'), label),
    h('button', { class: 'more', title: 'More ways to work on this', onclick: (e) => {
      e.stopPropagation();
      if (menu) return close();
      menu = h('div', { class: 'menu' },
        h('button', { onclick: () => act({ action: 'claude', folder, path }) }, icon('claude', 'sm'), 'Open in Claude Code'),
        h('button', { onclick: () => act({ action: 'terminal', folder, path }) }, icon('terminal', 'sm'), 'Open in Terminal'),
        h('button', { onclick: () => act({ action: 'finder', folder, path }) }, icon('finder', 'sm'), 'Show in Finder'));
      wrap.append(menu);
      setTimeout(() => document.addEventListener('click', close));
    } }, icon('down', 'sm')));
  return wrap;
}

/** A commit's files as a folder tree, each file with its badge. */
function changeTree(folder, changes) {
  const tree = h('div', { class: 'tree' });
  const sorted = [...changes].sort((a, b) => a.path.localeCompare(b.path));
  let shown = 0;
  const seenDirs = new Set();
  const draw = (limit) => {
    for (const c of sorted.slice(shown, limit)) {
      const parts = c.path.split('/');
      for (let d = 1; d < parts.length; d++) {
        const dir = parts.slice(0, d).join('/');
        if (seenDirs.has(dir)) continue;
        seenDirs.add(dir);
        tree.append(h('div', { class: 'row', style: `padding-left:${(d - 1) * 22}px` }, icon('folder', 'sm'), h('span', { class: 'nm' }, parts[d - 1])));
      }
      tree.append(h('div', {
        class: `row file ${c.status}`, style: `padding-left:${(parts.length - 1) * 22}px`,
        title: c.oldPath ? `Moved from ${c.oldPath}` : c.path,
        onclick: () => go({ page: 'file', folder, path: c.path, history: c.status === 'deleted' }),
      }, icon('file', 'sm'), h('span', { class: 'nm' }, parts.at(-1)), h('span', { class: `badge ${c.status}` }, BADGE[c.status])));
    }
    shown = Math.min(limit, sorted.length);
    if (shown < sorted.length) {
      const more = h('div', { class: 'more', onclick: () => { more.remove(); draw(sorted.length); } }, `+ ${sorted.length - shown} more`);
      tree.append(more);
    }
  };
  draw(TREE_ROWS);
  return tree;
}

function changeCard(c, { chip = false, work = false } = {}) {
  return h('div', { class: 'card' },
    h('div', { class: 'card-head' },
      chip && h('span', { class: 'chip' }, CHIP[c.folder]),
      h('span', { class: 'subject', title: c.subject }, c.subject || '(no message)'),
      h('span', { class: 'meta' }, `${c.author} · ${shortWhen(c.date)}`),
      work && workButton(c.folder, '', 'Work on this', true)),
    c.changes.length ? [h('div', { class: 'rule' }), changeTree(c.folder, c.changes)] : null);
}

/** Commits grouped under day headers, appended to `into`. */
function appendDays(into, commits, opts, lastDay) {
  for (const c of commits) {
    const k = dayKey(c.date);
    if (k !== lastDay.value) {
      lastDay.value = k;
      into.append(h('div', { class: 'day' }, dayFmt.format(new Date(c.date)).replace(/\./g, '')));
    }
    into.append(changeCard(c, opts));
  }
}

function renderMarkdown(text, folder, baseDir) {
  let props = null;
  const fm = text.match(/^﻿?---\r?\n([\s\S]*?)\r?\n---\r?\n?/);
  if (fm) {
    text = text.slice(fm[0].length);
    // Top-level keys only; a key's indented or "- " lines (a YAML list or block) join its value.
    const rows = [];
    for (const l of fm[1].split(/\r?\n/)) {
      const m = l.match(/^([\w-]+):\s*(.*)$/);
      if (m) rows.push([m[1], m[2], []]);
      else if (rows.length && /^\s+\S|^-\s/.test(l)) rows.at(-1)[2].push(l);
    }
    const clean = (v) => v.trim().replace(/^-\s*/, '').replace(/^["']|["']$/g, '');
    // A flat "- item" list reads as "IT, US"; anything nested keeps its shape as text.
    const value = (inline, block) => !block.length ? clean(inline)
      : block.every((l) => /^\s*-\s/.test(l) && !/:\s/.test(l)) ? block.map(clean).join(', ')
      : h('pre', { class: 'fm-block' }, block.join('\n'));
    props = h('dl', { class: 'props' }, rows.flatMap(([k, inline, block]) => [h('dt', {}, k), h('dd', {}, value(inline, block))]));
  }
  const body = h('div', { class: 'md' });
  // No styles (a note could otherwise cover the window with a fake one) and no image maps
  // (their links are not the page's links).
  body.innerHTML = DOMPurify.sanitize(marked.parse(text, { gfm: true }), {
    FORBID_TAGS: ['style', 'form', 'input', 'map', 'area'], FORBID_ATTR: ['style'],
  });
  // The copyright notice every repo README opens with is for GitHub, not for reading here.
  for (const q of body.querySelectorAll('blockquote')) {
    if (/^\s*Proprietary Notice:/i.test(q.textContent)) q.remove();
  }
  // Relative images come from the brain itself; anything else that is not a web image is dropped.
  for (const img of body.querySelectorAll('img')) {
    const src = img.getAttribute('src') || '';
    if (/^https?:/i.test(src)) img.replaceWith(h('a', { href: src }, img.alt || src));
    else { const p = joinPath(baseDir, src); p == null ? img.remove() : img.setAttribute('src', `file/${folder}/${p.split('/').map(encodeURIComponent).join('/')}`); }
  }
  for (const a of body.querySelectorAll('a')) {
    const href = a.getAttribute('href') || '';
    a.addEventListener('click', (e) => {
      e.preventDefault();
      if (/^(https?:|mailto:)/i.test(href)) return act({ action: 'link', url: href });
      if (href.startsWith('#')) return document.getElementById(href.slice(1))?.scrollIntoView();
      const p = joinPath(baseDir, href.split('#')[0]);
      if (p != null) go({ page: /\.[a-z0-9]+$/i.test(p) ? 'file' : 'folder', folder, path: p.replace(/\/$/, '') });
    });
  }
  return [props, body];
}

/** `href` relative to `dir`, normalised; null when it climbs out of the folder. */
function joinPath(dir, href) {
  let decoded;
  try { decoded = decodeURIComponent(href); } catch { return null; }
  const parts = (decoded.startsWith('/') ? [] : (dir ? dir.split('/') : [])).concat(decoded.split('/'));
  const out = [];
  for (const p of parts) {
    if (!p || p === '.') continue;
    if (p === '..') { if (!out.length) return null; out.pop(); } else out.push(p);
  }
  return out.join('/');
}

const parentOf = (p) => p.includes('/') ? p.slice(0, p.lastIndexOf('/')) : '';
const message = (text) => h('div', { class: 'message' }, text);

// ---------- Brand knowledge / Team / Personal: a folder's Overview ----------

function folderView(r) {
  const info = state.folders.find((f) => f.id === r.folder);
  const { bar, setLast } = toolbar(r, null);
  const overview = h('div', { class: 'overview' });
  const col = h('aside', { class: 'changes-col' });
  const el = h('div', {}, bar, h('div', { class: 'folder' + (prefs.columnFolded ? ' folded' : '') }, overview, info?.isRepo ? col : null));
  bar.append(
    h('button', { class: 'iconbtn', title: 'Show in Finder', onclick: () => act({ action: 'finder', folder: r.folder, path: r.path }) }, icon('finder')),
    h('button', { class: 'iconbtn', title: 'Reload', onclick: () => render() }, icon('reload')));

  async function load(current) {
    if (info && !info.exists) { overview.replaceChildren(message('This folder is not on this Mac yet. It appears once brain-sync has set this Mac up.')); return; }
    const list = await ask({ op: 'list', folder: r.folder, path: r.path });
    if (!current()) return;
    setLast(list.last);
    if (list.description) overview.append(h('p', { class: 'folder-desc' }, list.description));
    if (list.readme) {
      const md = await ask({ op: 'read', folder: r.folder, path: list.readme });
      if (!current()) return;
      if (md.kind === 'markdown') overview.append(readmeBlock(md.text, r));
    }
    overview.append(runList(r, list.entries));
    if (info?.isRepo) loadColumn(col, r, current);
  }
  return { el, load, fail: (e) => overview.replaceChildren(message(e.message)) };
}

function readmeBlock(text, r) {
  const body = h('div', { class: 'body' }, renderMarkdown(text, r.folder, r.path));
  const box = h('div', { class: 'readme' }, body);
  const toggle = h('button', { class: 'toggle', onclick: () => {
    box.classList.toggle('open');
    toggle.replaceChildren(box.classList.contains('open') ? 'Show less' : 'Read the full README', icon('down', 'sm'));
  } }, 'Read the full README', icon('down', 'sm'));
  // Only a README that does not fit gets the fold and the button.
  requestAnimationFrame(() => { if (body.scrollHeight > body.clientHeight + 24) { box.classList.add('folds'); box.append(toggle); } });
  return box;
}

function runList(r, entries) {
  const list = h('ul', { class: 'runlist' });
  const count = h('span', {});
  const filter = h('input', { class: 'filter', placeholder: 'Find in this folder', type: 'search' });
  const draw = () => {
    const q = filter.value.trim().toLowerCase();
    const shown = entries.filter((e) => !q || e.name.toLowerCase().includes(q) || (e.description || '').toLowerCase().includes(q));
    count.textContent = `${shown.length} item${shown.length === 1 ? '' : 's'}`;
    list.replaceChildren(...shown.map((e) => h('li', {}, h('button', {
      title: e.name, onclick: () => go({ page: e.isDir ? 'folder' : 'file', folder: r.folder, path: e.path }),
    }, icon(e.isDir ? 'folder' : 'file'), h('span', { class: 'txt' },
      h('span', { class: 'nm' }, e.name), e.description ? h('span', { class: 'desc' }, e.description) : null)))));
    if (!shown.length) list.replaceChildren(h('li', { class: 'empty' }, q ? 'Nothing here matches.' : 'This folder is empty.'));
  };
  filter.addEventListener('input', draw);
  filter.hidden = true;
  const searchBtn = h('button', { class: 'iconbtn', title: 'Find in this folder', onclick: () => { filter.hidden = !filter.hidden; if (!filter.hidden) filter.focus(); else { filter.value = ''; draw(); } } }, icon('search'));
  draw();
  return h('div', {}, h('div', { class: 'countrule' }, count, searchBtn), filter, list);
}

async function loadColumn(col, r, current) {
  const folderEl = col.parentElement;
  const days = h('div', {});
  const lastDay = { value: null };
  let skip = 0;
  const more = h('button', { class: 'loadmore', onclick: () => page() });
  more.textContent = 'Show older changes';
  col.replaceChildren(
    h('div', { class: 'col-head' },
      h('span', { class: 'title' }, 'Recent changes'),
      h('button', { class: 'iconbtn hide-folded', title: 'Reload', onclick: () => { col.replaceChildren(); loadColumn(col, r, current); } }, icon('reload', 'sm')),
      h('button', { class: 'iconbtn', title: 'Fold the column', onclick: () => {
        prefs.columnFolded = folderEl.classList.toggle('folded'); savePrefs();
      } }, icon('column', 'sm'))),
    days);
  async function page() {
    const res = await ask({ op: 'changes', folder: r.folder, path: r.path, limit: PAGE_SIZE, skip });
    if (!current()) return;
    const commits = res.commits || [];
    if (!skip && !commits.length) days.replaceChildren(h('div', { class: 'empty' }, 'No changes yet.'));
    appendDays(days, commits, {}, lastDay);
    skip += commits.length;
    commits.length === PAGE_SIZE ? col.append(more) : more.remove();
  }
  await page();
}

// ---------- a file ----------

function fileView(r) {
  const { bar, setLast } = toolbar(r, null);
  const article = h('div', { class: 'file-article' });
  const hist = h('aside', { class: 'history-col' });
  const showHistory = !!r.history;
  const histBtn = h('button', { class: 'iconbtn' + (showHistory ? ' on' : ''), title: 'History', onclick: () => go({ ...r, history: !showHistory }) }, icon('clock'));
  bar.append(histBtn,
    h('button', { class: 'iconbtn', title: 'Show in Finder', onclick: () => act({ action: 'finder', folder: r.folder, path: r.path }) }, icon('finder')),
    h('button', { class: 'iconbtn', title: 'Reload', onclick: () => render() }, icon('reload')));
  const el = h('div', {}, bar, h('div', { class: 'file' }, article, showHistory ? hist : null));

  async function load(current) {
    const f = await ask({ op: 'read', folder: r.folder, path: r.path });
    if (!current()) return;
    setLast(f.last);
    const inner = h('div', { class: 'inner' });
    article.replaceChildren(resizable(inner));
    const base = parentOf(r.path);
    switch (f.kind) {
      case 'markdown': inner.append(...renderMarkdown(f.text, r.folder, base).filter(Boolean)); break;
      case 'text': inner.append(h('pre', { class: 'text' }, f.text)); break;
      case 'image': inner.append(h('div', { class: 'image-view' }, h('img', { src: `file/${r.folder}/${r.path.split('/').map(encodeURIComponent).join('/')}`, alt: r.path }))); break;
      case 'tooLarge': inner.append(message(`Too large to show here (${Math.round(f.size / 1e5) / 10} MB). Use Show in Finder.`)); break;
      case 'binary': inner.append(message('No preview for this kind of file. Use Show in Finder.')); break;
      default: inner.append(message(showHistory ? 'This file is no longer here. Its history is on the right.' : 'This file is no longer here: it was moved or deleted.'));
    }
    if (showHistory) await loadHistory(hist, r, current);
  }
  return { el, load, fail: (e) => article.replaceChildren(message(e.message)) };
}

// Drag either edge of a document to make it wider or narrower; double-click an edge to reset.
// The width is remembered for every document.
const DOC_WIDTH = { def: 820, min: 480, max: 1600 };
function resizable(inner) {
  const apply = () => { inner.style.maxWidth = (prefs.docWidth || DOC_WIDTH.def) + 'px'; };
  const edge = (side) => h('div', {
    class: `doc-edge ${side}`, title: 'Drag to resize · double-click to reset',
    ondblclick: () => { delete prefs.docWidth; savePrefs(); apply(); },
    onpointerdown: (ev) => {
      ev.preventDefault();
      const el = ev.currentTarget;
      el.setPointerCapture(ev.pointerId);
      const x0 = ev.clientX, w0 = inner.getBoundingClientRect().width;
      const sign = side === 'right' ? 1 : -1;
      el.classList.add('dragging');
      const move = (e) => {
        // The page is centred on its column, so each edge moves half the change: double it.
        const w = Math.round(Math.min(DOC_WIDTH.max, Math.max(DOC_WIDTH.min, w0 + sign * 2 * (e.clientX - x0))));
        prefs.docWidth = w; apply();
      };
      const up = () => { el.classList.remove('dragging'); el.removeEventListener('pointermove', move); el.removeEventListener('pointerup', up); savePrefs(); };
      el.addEventListener('pointermove', move);
      el.addEventListener('pointerup', up);
    },
  });
  apply();
  return h('div', { class: 'doc-frame' }, edge('left'), inner, edge('right'));
}

async function loadHistory(col, r, current) {
  const info = state.folders.find((f) => f.id === r.folder);
  if (!info?.isRepo) { col.replaceChildren(message('Personal files are private to this Mac and have no history.')); return; }
  const res = await ask({ op: 'history', folder: r.folder, path: r.path });
  if (!current()) return;
  const commits = res.commits || [];
  const list = h('div', { class: 'hist-list' });
  const diff = h('div', { class: 'diff' });
  col.replaceChildren(h('div', { class: 'col-head' }, h('span', { class: 'title' }, 'History')), list, diff);
  if (!commits.length) { diff.replaceWith(h('div', { class: 'empty' }, 'No saved changes for this file yet.')); return; }
  const show = async (c, btn) => {
    list.querySelectorAll('.hist-item').forEach((b) => b.classList.remove('on'));
    btn.classList.add('on');
    if (!c.changes[0]) { diff.textContent = 'This change has no file differences to show.'; return; }
    diff.textContent = 'Loading…';
    try {
      const d = await ask({ op: 'diff', folder: r.folder, hash: c.hash, change: c.changes[0] });
      if (!current() || !btn.classList.contains('on')) return;
      diff.replaceChildren(...d.diff.split('\n').map((l) => h('span', {
        class: l.startsWith('+') && !l.startsWith('+++') ? 'add' : l.startsWith('-') && !l.startsWith('---') ? 'del' : l.startsWith('@@') ? 'hunk' : '',
      }, l + '\n')));
    } catch (e) { diff.textContent = e.message; }
  };
  for (const c of commits) {
    const b = h('button', { class: 'hist-item', onclick: () => show(c, b) },
      h('div', { class: 's' }, c.subject || '(no message)'),
      h('div', { class: 'm' }, `${c.author} · ${new Date(c.date).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })}`
        + (c.changes[0]?.status && c.changes[0].status !== 'edited' ? ` · ${BADGE[c.changes[0].status]}` : '')));
    list.append(b);
  }
  if (commits[0].changes.length) show(commits[0], list.firstChild);
}

// ---------- Activity ----------

function activityView() {
  const days = h('div', {});
  const lastDay = { value: null };
  const more = h('button', { class: 'loadmore', onclick: () => page() }, 'Show older activity');
  let skip = 0;
  const box = h('div', { class: 'activity' }, h('h1', {}, 'Latest activity'), days);
  let isCurrent = () => true;
  async function page() {
    const res = await ask({ op: 'changes', limit: PAGE_SIZE, skip });
    if (!isCurrent()) return;
    const commits = res.commits;
    if (commits == null) { days.replaceChildren(message("The brain's history can't be read on this Mac yet.")); return; }
    if (!skip && !commits.length) days.replaceChildren(message('No activity yet.'));
    appendDays(days, commits, { chip: true, work: true }, lastDay);
    skip += commits.length;
    commits.length === PAGE_SIZE ? box.append(more) : more.remove();
  }
  return { el: box, load: (current) => { isCurrent = current; return page(); }, fail: (e) => days.replaceChildren(message(e.message)) };
}

// ---------- the Brain map ----------
// Every document in the shared brains as a dot, coloured by area (its top-level folder), with a
// line wherever one document mentions another. Laid out by a small force simulation: links pull,
// dots push apart, each area gathers around its own spot. Drag to pan, scroll to zoom, click a dot
// to open the document.

const AREA_COLORS = ['#2754a5', '#2e7d3a', '#b42318', '#8a5a00', '#6b3fa0', '#0f7b7b', '#c2410c', '#4a505a', '#9d174d', '#3f6212', '#1e40af', '#92400e'];

function mapView() {
  const wrap = h('div', { class: 'map' });
  const canvas = h('canvas', { class: 'map-canvas' });
  const tip = h('div', { class: 'map-tip', hidden: true });
  const legend = h('div', { class: 'map-legend' });
  const filter = h('input', { class: 'filter map-filter', type: 'search', placeholder: 'Find a document' });
  const info = h('div', { class: 'map-info' });
  wrap.append(h('div', { class: 'map-head' }, h('h1', { class: 'page-title' }, 'Brain map'), info, filter), legend, h('div', { class: 'map-stage' }, canvas, tip));

  async function load(current) {
    info.textContent = 'Reading the brain…';
    const m = await ask({ op: 'map' });
    if (!current()) return;
    const nodes = m.nodes.map((n, i) => ({ ...n, i, key: `${n.folder}:${n.area || '(root)'}`, deg: 0, x: 0, y: 0, vx: 0, vy: 0 }));
    for (const [a, b] of m.edges) { nodes[a].deg++; nodes[b].deg++; }
    if (!nodes.length) { info.textContent = ''; wrap.append(message('No documents yet: the map appears once the brain has markdown files.')); return; }
    info.textContent = `${nodes.length} documents · ${m.edges.length} links${m.truncated ? ' · partial (very large brain)' : ''}`;

    // Areas: biggest first, each on its own spot around a circle.
    const areas = [...nodes.reduce((acc, n) => acc.set(n.key, (acc.get(n.key) || 0) + 1), new Map())].sort((a, b) => b[1] - a[1]);
    const area = new Map(areas.map(([key, count], k) => {
      const ang = (k / areas.length) * Math.PI * 2;
      const rad = 60 * Math.sqrt(nodes.length);
      return [key, { key, count, color: k < AREA_COLORS.length ? AREA_COLORS[k] : `hsl(${Math.round((k * 137.5) % 360)} 55% 45%)`, ax: Math.cos(ang) * rad, ay: Math.sin(ang) * rad, on: true }];
    }));
    for (const n of nodes) { const a = area.get(n.key); n.x = a.ax + (Math.random() - .5) * 80; n.y = a.ay + (Math.random() - .5) * 80; }
    const label = (key) => { const [f, a] = key.split(':'); return `${CHIP[f] || f} · ${a}`; };
    legend.replaceChildren(...[...area.values()].map((a) => {
      const b = h('button', { class: 'chip', title: 'Show or hide this area' }, h('span', { class: 'sw', style: `background:${a.color}` }), `${label(a.key)} `, h('small', {}, String(a.count)));
      b.addEventListener('click', () => { a.on = !a.on; b.classList.toggle('off', !a.on); draw(); });
      return b;
    }));

    // Force layout, run up front (about a second for a few thousand documents), then drawn.
    const edges = m.edges;
    const ticks = Math.min(300, 60 + Math.round(200000 / Math.max(1, nodes.length)));
    for (let t = 0; t < ticks; t++) {
      const alpha = 1 - t / ticks;
      for (let i = 0; i < nodes.length; i++) {
        const p = nodes[i];
        for (let j = i + 1; j < nodes.length; j++) {
          const q = nodes[j];
          let dx = p.x - q.x, dy = p.y - q.y, d2 = dx * dx + dy * dy + .01;
          if (d2 > 90000) continue;
          const f = 900 * alpha / d2;
          dx *= f; dy *= f; p.vx += dx; p.vy += dy; q.vx -= dx; q.vy -= dy;
        }
      }
      for (const [a, b] of edges) {
        const p = nodes[a], q = nodes[b];
        const dx = q.x - p.x, dy = q.y - p.y, d = Math.sqrt(dx * dx + dy * dy) || 1;
        const f = (d - 40) * .02 * alpha / d;
        p.vx += dx * f; p.vy += dy * f; q.vx -= dx * f; q.vy -= dy * f;
      }
      for (const n of nodes) {
        const a = area.get(n.key);
        n.vx += (a.ax - n.x) * .004 * alpha; n.vy += (a.ay - n.y) * .004 * alpha;
        n.x += n.vx = Math.max(-40, Math.min(40, n.vx * .6)); n.y += n.vy = Math.max(-40, Math.min(40, n.vy * .6));
      }
    }

    // View: fit everything, then pan and zoom.
    const ctx = canvas.getContext('2d');
    let scale = 1, ox = 0, oy = 0, hover = null, moved = false;   // moved: panned or zoomed, so a resize keeps the view
    const radius = (n) => 3 + Math.min(9, Math.sqrt(n.deg) * 1.6);
    function fit() {
      const r = canvas.getBoundingClientRect();
      const xs = nodes.map((n) => n.x), ys = nodes.map((n) => n.y);
      const [x0, x1, y0, y1] = [Math.min(...xs), Math.max(...xs), Math.min(...ys), Math.max(...ys)];
      scale = Math.min(r.width / (x1 - x0 + 80), r.height / (y1 - y0 + 80), 3);
      ox = r.width / 2 - scale * (x0 + x1) / 2; oy = r.height / 2 - scale * (y0 + y1) / 2;
    }
    function size() {
      const r = canvas.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
      canvas.width = Math.round(r.width * dpr); canvas.height = Math.round(r.height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }
    const visible = (n) => area.get(n.key).on;
    function draw() {
      const r = canvas.getBoundingClientRect();
      ctx.clearRect(0, 0, r.width, r.height);
      const q = filter.value.trim().toLowerCase();
      const hit = (n) => !q || n.path.toLowerCase().includes(q);
      const near = hover ? new Set(edges.filter(([a, b]) => a === hover.i || b === hover.i).flat()) : null;
      ctx.lineWidth = 1;
      for (const [a, b] of edges) {
        const p = nodes[a], s2 = nodes[b];
        if (!visible(p) || !visible(s2)) continue;
        const lit = near && (a === hover.i || b === hover.i);
        ctx.strokeStyle = lit ? 'rgba(29,33,40,.55)' : q ? 'rgba(29,33,40,.04)' : 'rgba(29,33,40,.10)';
        ctx.beginPath(); ctx.moveTo(ox + p.x * scale, oy + p.y * scale); ctx.lineTo(ox + s2.x * scale, oy + s2.y * scale); ctx.stroke();
      }
      for (const n of nodes) {
        if (!visible(n)) continue;
        const dim = (q && !hit(n)) || (near && !near.has(n.i));
        ctx.globalAlpha = dim ? .15 : 1;
        ctx.fillStyle = area.get(n.key).color;
        ctx.beginPath(); ctx.arc(ox + n.x * scale, oy + n.y * scale, radius(n) * Math.max(.6, Math.min(1.6, scale)), 0, Math.PI * 2); ctx.fill();
      }
      ctx.globalAlpha = 1;
      if (hover) {
        ctx.strokeStyle = '#1d2128'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.arc(ox + hover.x * scale, oy + hover.y * scale, radius(hover) * Math.max(.6, Math.min(1.6, scale)) + 2, 0, Math.PI * 2); ctx.stroke();
      }
    }
    function at(ev) {
      const r = canvas.getBoundingClientRect(), x = (ev.clientX - r.left - ox) / scale, y = (ev.clientY - r.top - oy) / scale;
      let best = null, bd = Infinity;
      for (const n of nodes) {
        if (!visible(n)) continue;
        const d = (n.x - x) ** 2 + (n.y - y) ** 2;
        if (d < bd) { bd = d; best = n; }
      }
      const reach = (radius(best || { deg: 0 }) + 4) / Math.min(1, scale);
      return best && bd <= reach * reach ? best : null;
    }
    let drag = null;
    canvas.addEventListener('pointerdown', (ev) => { drag = { x: ev.clientX, y: ev.clientY, ox, oy, moved: false }; canvas.setPointerCapture(ev.pointerId); });
    canvas.addEventListener('pointermove', (ev) => {
      if (drag) {
        const dx = ev.clientX - drag.x, dy = ev.clientY - drag.y;
        if (Math.abs(dx) + Math.abs(dy) > 3) drag.moved = true;
        ox = drag.ox + dx; oy = drag.oy + dy; if (drag.moved) moved = true; tip.hidden = true; draw(); return;
      }
      const n = at(ev);
      if (n !== hover) { hover = n; draw(); }
      canvas.style.cursor = n ? 'pointer' : 'grab';
      if (n) {
        const r = canvas.getBoundingClientRect();
        tip.replaceChildren(h('b', {}, n.path.split('/').pop()), h('span', {}, `${CHIP[n.folder]} · ${n.path} · ${n.deg} link${n.deg === 1 ? '' : 's'}`));
        tip.hidden = false;
        // Kept inside the stage: near the right or bottom edge it flips to the other side of the pointer.
        let tx = ev.clientX - r.left + 14, ty = ev.clientY - r.top + 14;
        if (tx + tip.offsetWidth > r.width - 8) tx = Math.max(8, ev.clientX - r.left - 14 - tip.offsetWidth);
        if (ty + tip.offsetHeight > r.height - 8) ty = Math.max(8, ev.clientY - r.top - 14 - tip.offsetHeight);
        tip.style.left = `${tx}px`; tip.style.top = `${ty}px`;
      } else tip.hidden = true;
    });
    canvas.addEventListener('pointerup', (ev) => {
      const was = drag; drag = null;
      if (was && !was.moved) { const n = at(ev); if (n) go({ page: 'file', folder: n.folder, path: n.path }); }
    });
    canvas.addEventListener('pointerleave', () => { if (!drag) { hover = null; tip.hidden = true; draw(); } });
    canvas.addEventListener('wheel', (ev) => {
      ev.preventDefault();
      const r = canvas.getBoundingClientRect(), mx = ev.clientX - r.left, my = ev.clientY - r.top;
      const k = Math.exp(-ev.deltaY * .0015), next = Math.min(8, Math.max(.05, scale * k));
      ox = mx - (mx - ox) * (next / scale); oy = my - (my - oy) * (next / scale); scale = next; moved = true; draw();
    }, { passive: false });
    canvas.addEventListener('dblclick', () => { moved = false; fit(); draw(); });
    filter.addEventListener('input', draw);
    const ro = new ResizeObserver(() => { if (!canvas.isConnected) return ro.disconnect(); size(); if (!moved) fit(); draw(); });
    ro.observe(canvas);
    size(); fit(); draw();
  }
  return { el: wrap, load, fail: (e) => { info.textContent = ''; wrap.append(message(e.message)); } };
}

// ---------- Search ⌘K ----------

/** `text` with the part `match` points at (UTF-16 offsets, as the bridge reports them) marked. */
function markMatch(text, match) {
  if (!match) return [text];
  const end = match.start + match.length;
  return [text.slice(0, match.start), h('mark', {}, text.slice(match.start, end)), text.slice(end)];
}

/** A line starting just before its match, so a match far along the row is not lost to the ellipsis. */
function nearMatch(text, match) {
  const lead = 40;
  if (match.start <= lead) return markMatch(text, match);
  const cut = match.start - lead;
  return markMatch('…' + text.slice(cut), { start: lead + 1, length: match.length });
}

let searchSeq = 0;
function openSearch({ inNewTab = false } = {}) {
  if (document.querySelector('.palette-backdrop')) { document.querySelector('.palette input')?.focus(); return; }
  const input = h('input', { type: 'search', placeholder: 'Search files, the words inside them, and changes', spellcheck: 'false' });
  const results = h('div', { class: 'results' });
  const backdrop = h('div', { class: 'palette-backdrop', onmousedown: (e) => { if (e.target === backdrop) close(); } },
    h('div', { class: 'palette', role: 'dialog', 'aria-label': 'Search' },
      h('div', { class: 'palette-input' }, icon('search'), input), results));
  let items = [];
  let at = 0;
  let pending = false;   // a newer query is on its way: the list on screen is the old one
  let timer = null;
  const close = () => { clearTimeout(timer); backdrop.remove(); searchSeq++; };
  const open = (r) => { close(); inNewTab ? newTab(r) : go(r); };
  const highlight = () => items.forEach((it, i) => {
    it.el.classList.toggle('on', i === at);
    if (i === at) it.el.scrollIntoView({ block: 'nearest' });
  });
  const add = (title, rows) => {
    if (!rows.length) return;
    results.append(h('div', { class: 'section' }, title));
    for (const [route, ...kids] of rows) {
      const i = items.length;
      const el = h('button', { class: 'result', onmousemove: () => { if (at !== i) { at = i; highlight(); } }, onclick: () => open(route) }, ...kids);
      items.push({ el, route });
      results.append(el);
    }
  };
  const where = (folder, path) => h('span', { class: 'where' }, CHIP[folder] + (parentOf(path) ? ' / ' + parentOf(path) : ''));
  async function search() {
    const q = input.value.trim();
    const seq = ++searchSeq;
    const done = () => { pending = false; results.classList.remove('stale'); };
    if ([...q].length < 2) { done(); results.replaceChildren(h('div', { class: 'hint' }, 'Type at least two letters.')); items = []; return; }
    let res;
    try { res = await ask({ op: 'search', query: q }); } catch (e) { if (seq === searchSeq) { done(); results.replaceChildren(h('div', { class: 'hint' }, e.message)); } return; }
    if (seq !== searchSeq) return;   // a newer keystroke already asked
    done();
    results.replaceChildren();
    items = [];
    add('Files', res.names.map((n) => [{ page: n.isDir ? 'folder' : 'file', folder: n.folder, path: n.path },
      icon(n.isDir ? 'folder' : 'file', 'sm'), h('span', { class: 'what' }, markMatch(n.path.split('/').pop(), n.match)), where(n.folder, n.path)]));
    add('Inside files', res.lines.map((l) => [{ page: 'file', folder: l.folder, path: l.path },
      icon('file', 'sm'), h('span', { class: 'what' }, h('span', { class: 'line' }, ...nearMatch(l.text, l.match))),
      h('span', { class: 'where' }, `${l.path.split('/').pop()} · line ${l.line}`)]));
    add('Changes', res.changes.map((c) => [c.changes[0] ? { page: 'file', folder: c.folder, path: c.changes[0].path, history: true } : { page: 'activity' },
      icon('clock', 'sm'), h('span', { class: 'what' }, c.subject), h('span', { class: 'where' }, `${CHIP[c.folder]} · ${c.author} · ${shortWhen(c.date)}`)]));
    if (!items.length) results.append(h('div', { class: 'hint' }, `Nothing in the brain matches “${q}”.`));
    at = 0;
    highlight();
  }
  input.addEventListener('input', () => {
    pending = true;
    results.classList.add('stale');
    clearTimeout(timer);
    timer = setTimeout(search, 160);
  });
  backdrop.addEventListener('keydown', (e) => { if (e.key === 'Escape') { e.preventDefault(); close(); } });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' || pending && e.key === 'Enter') { e.preventDefault(); return; }
    else if (e.key === 'ArrowDown' && items.length) { e.preventDefault(); at = (at + 1) % items.length; highlight(); }
    else if (e.key === 'ArrowUp' && items.length) { e.preventDefault(); at = (at - 1 + items.length) % items.length; highlight(); }
    else if (e.key === 'Enter' && items[at]) { e.preventDefault(); open(items[at].route); }
  });
  results.append(h('div', { class: 'hint' }, 'Type at least two letters.'));
  document.body.append(backdrop);
  input.focus();
}

// ---------- start ----------

async function refreshState() {
  try { state = await ask({ op: 'state' }); } catch (e) { state = { folders: [], sync: null, person: null, error: e.message }; }
}

await refreshState();
newTab({ page: 'folder', folder: 'brand', path: '' });
setInterval(async () => { await refreshState(); renderSidebar(); }, 30000);
document.addEventListener('keydown', (e) => {
  if (!e.metaKey) return;
  if (e.key === 'k') { e.preventDefault(); return openSearch(); }
  if (document.querySelector('.palette-backdrop')) return;   // the palette has the keyboard
  if (e.key === '[') step(-1);
  else if (e.key === ']') step(1);
  else if (e.key === 't') { e.preventDefault(); newTab({ page: 'folder', folder: 'brand', path: '' }); }
  else if (e.key === 'w') { e.preventDefault(); closeTab(active); }
  else if (e.key === 'r') { e.preventDefault(); render(); }
  else if (e.key === 'j') { const r = route(); if (r.folder) act({ action: 'claude', folder: r.folder, path: r.path }); }
});
