// What's new, newest first. Each release adds its entry here in the same pull request that bumps
// VERSION (scripts/test.sh checks that the top entry matches VERSION). Written for the team, not
// for developers: what they can now do, in plain words.
export const CHANGELOG = [
  { version: '0.9.0', date: '2026-11-17', items: [
    'The Home is now the Company Brain (what used to be Brand knowledge): the app opens on its folders, so you see how the Brain is organised at a glance. The home button in the top bar takes you back to it.',
    'Activity, the latest changes, is now its own section in the sidebar.',
    'Work in Claude is always in the top bar, on every page: it opens Claude on the folder or file you are looking at.',
    'Skills has its own Work on this button too.',
    'One Search (⌘K) finds files by name and by the words inside them. Go to file is gone; ⌘P opens the same Search.',
  ] },
  { version: '0.8.2', date: '2026-11-13', items: [
    'Signing out while the app is checking your MediaBuy access can no longer leave you signed in.',
  ] },
  { version: '0.8.1', date: '2026-11-13', items: [
    'A skills permission Max gives you (or takes away) in MediaBuy now shows by itself: when the app starts and when you open Skills. No need to sign out and in again.',
  ] },
  { version: '0.8.0', date: '2026-11-12', items: [
    'Skills: a new page in the sidebar lists the skills Claude uses in this Brain, with what each is for. Click one to open its files and history.',
    'People Max allows to publish skills (shown as "Skills" under your name) get Upload, Replace, Delete and Restore there. A skill published this way reaches every Mac within about 10 minutes, without a pull request.',
    'If MediaBuy refuses a skill, the app says why in plain words (a script inside, a description too short, a name already taken…), and nothing changes.',
  ] },
  { version: '0.7.2', date: '2026-11-09', items: [
    'Sign in with MediaBuy: your email and Editor or Reader in the sidebar, from your MediaBuy role. Editors can add files to Brand knowledge.',
    'A new Mac sets itself up from the sign-in: open the app, click Sign in with MediaBuy, and the folders appear. No line to send, no Terminal.',
    'New Macs set up from the app trust the automatic release signature too.',
  ] },
  { version: '0.7.1', date: '2026-11-09', items: [
    'Debug console: the >_ button next to Sync now (or ⌥⌘J) opens a panel at the bottom of the window with what brain-sync and the app are doing, live. Search it, copy it, or show the log file in Finder. Tokens and keys are never shown.',
    'The console folds the lines a quiet sync repeats every 5 minutes into one row (×N, first–last time), shows problems in red and warnings in amber, counts the errors of the last 24 hours, and has an "Errors only" switch. Copy takes the folded view; Copy raw every line.',
  ] },
  { version: '0.7.0', date: '2026-11-08', items: [
    'Sync now: the round arrow next to the sync status starts a sync in the background. It no longer opens Terminal.',
    'Simpler navigation: open folders right in the sidebar like Finder, and press ⌘P to open any file by typing a few letters of its name.',
    'Brain map in 3D: the brain floats and turns in space, each area its own cluster. Drag to rotate, scroll to zoom, hover a document to light up what it links to, type a name and press Enter to fly to it.',
    'Add files: an "Add files" button on every folder you may write to, or drop files from Finder onto the window. They reach the team on the next sync.',
    'Brand knowledge accepts files only on a Mac allowed to edit the Brain; Team files and Personal files always do.',
    'Move to Trash for Personal files (a file or a folder), after a confirmation. It goes to the Mac\'s Trash, so it can be put back. Shared folders never offer it.',
    'What\'s new: click the version under the logo to see what changed in each release.',
    '"Open in Obsidian" is gone from the menu.',
  ] },
  { version: '0.6.0', date: '2026-11-08', items: [
    'One app: the menu-bar status, Fix, Sync now and the set-up window moved into Serlino Brain, which replaces the old SerlinoLab Brain menu-bar app.',
    'It starts in the background at login with only the menu-bar dot. The Dock icon shows while the window is open; closing the window keeps the dot and the sync.',
    'Updates arrive by themselves with the sync, signed and checked.',
  ] },
  { version: '0.5.4', date: '2026-11-08', items: [
    'A tighter sidebar and tab bar: smaller menu text, more room for the page.',
    'Brain map: hidden folders like .claude are left out, every area has its own colour, and the hover label stays inside the map.',
    'READMEs no longer show the copyright notice at the top.',
  ] },
  { version: '0.5.0', date: '2026-11-08', items: [
    'Brain map: every document in the brain as a dot, coloured by area, with a line wherever one mentions another. Hover to see it, click to open it, filter to find one.',
  ] },
  { version: '0.4.0', date: '2026-11-08', items: [
    'Drag the edges of a document to make it wider or narrower; double-click an edge to reset.',
    'A folder can carry a one-line description (a .description file inside it), shown under its name.',
  ] },
  { version: '0.3.0', date: '2026-11-07', items: [
    'Signed with SerlinoLab\'s Developer ID and notarized by Apple: it opens on any Mac without a security warning.',
    'Search ⌘K across file names, the text inside documents and past changes.',
  ] },
  { version: '0.1.0', date: '2026-10-20', items: [
    'Serlino Brain: read the Brain, Team files and Personal files, see each file\'s history, follow the latest activity, and "Work on this" in Claude Code.',
  ] },
];
