// The Debug console's reading of a log, with no DOM, so it is tested on its own (scripts/test-ui.mjs).
//
// A quiet engine writes the same 2–3 lines every 5 minutes ("self-update: … rejected …", "mirror at X",
// "team at Y"). collapse() folds a line that repeats the last one of its kind (same source and same
// text) into that row, counting it (×N) and keeping the first and last time, so a night of quiet
// cycles is a handful of rows and a change (a new commit, a new error) still starts a new row.

const HASH = /\b[0-9a-f]{7,40}\b/g;

/** Severity of one line: 'error', 'warn' or ''. */
export function severity(text) {
  if (/\b(rejected|refused|failed|failure|error|fatal|denied|permission denied|needs (your )?attention|unreachable|could not|couldn't|problem|conflict)\b/i.test(text)) return 'error';
  if (/\b(warn(ing)?|retry(ing)?|retrying|skipp(ed|ing)|kept aside|stale|timed out)\b/i.test(text)) return 'warn';
  return '';
}

/** `lines` ({at: Date|null, src, text}) folded: rows {l, n, first, last} and day dividers {divider: Date}. */
export function collapse(lines) {
  const rows = [], lastOfKind = new Map();
  let day = '';
  for (const l of lines) {
    // The kind: source plus the first words with commit ids blanked ("sync:mirror at #").
    const kind = l.src + ':' + l.text.replace(HASH, '#').split(' ').slice(0, 3).join(' ');
    const prev = lastOfKind.get(kind);
    if (prev && prev.l.text === l.text) { prev.n++; prev.last = l.at; continue; }
    if (l.at) {
      const d = l.at.toDateString();
      if (d !== day) { if (day) rows.push({ divider: l.at }); day = d; }
    }
    const row = { l, n: 1, first: l.at, last: l.at };
    lastOfKind.set(kind, row);
    rows.push(row);
  }
  return rows;
}

/** Problems in the last `hours`: every line counts (a folded row counts as many as it holds). */
export function recentErrors(lines, now = new Date(), hours = 24) {
  const since = now.getTime() - hours * 3600 * 1000;
  return lines.filter((l) => l.at && l.at.getTime() >= since && severity(l.text) === 'error').length;
}
